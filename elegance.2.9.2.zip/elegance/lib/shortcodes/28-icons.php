<?php
/**
 *
 */
class mysiteIcons {

	/**
	 *
	 */
	static function icon( $atts = null, $content = null ) {
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Single Icon', 'elegance' ),
				'value' => 'icon',
				'options' => array(
					array(
						'name' => __( 'Select Preset Icon', 'elegance' ),
						'desc' => __( 'Select one of our icon presets to use.', 'elegance' ),
						'id' => 'type',
						'default' => '',
						'shortcode' => 'icon',
						'type' => 'icon_preset',
					),
					array(
						'id' => 'style',
						'default' => '',
						'type' => 'hidden',
					),
					array(
						'name' => __( 'Upload Custom Icon', 'elegance' ),
						'desc' => __( 'Upload your own icon to use.', 'elegance' ),
						'id' => 'custom_icon',
						'default' => '',
						'type' => 'upload',
					),
					array(
						'name' => __( 'Alignment', 'elegance' ),
						'desc' => __( 'Choose an alignment for your icon.', 'elegance' ),
						'id' => 'align',
						'default' => '',
						'options' => array(
							'left' => __('Left', 'elegance' ),
							'right' => __('Right', 'elegance' ),
							'center' => __('Center', 'elegance' ),
						),
						'type' => 'select'
					),
				'shortcode_has_atts' => true,
				)
			);

			return $option;
		}
		
		extract(shortcode_atts(array(
			'type' 	=> '',
			'style'	=> '',
			'custom_icon' 	=> '',
			'align' => '',
		), $atts));
		
		if ($align == "left") { $align = " alignleft"; }
		if ($align == "right") { $align = " alignright"; }
		if ($align == "center") { $align = " aligncenter"; }
		
		$src = THEME_IMAGES . '/icons/' . $style .'/'. $type . '.png';
		if (!empty($custom_icon)) { $src = $custom_icon; }
		
		$out = '<span class = "icon'.$align.'"><img src = "'.$src.'" alt = "" /></span>';
		
		return $out;
	}
	
	/**
	 *
	 */
	static function icon_teaser( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {

			$option = array( 
				'name' => __( 'Icon Teasers', 'elegance' ),
				'value' => 'icon_teaser',
				'options' => array(
					array(
						'name' => __( 'Select Preset Icon', 'elegance' ),
						'desc' => __( 'Select one of our icon presets to use.', 'elegance' ),
						'id' => 'type',
						'default' => '',
						'shortcode' => 'icon_teaser',
						'type' => 'icon_preset',
					),
					array(
						'id' => 'style',
						'default' => '',
						'type' => 'hidden',
					),
					array(
						'name' => __( 'Upload Custom Icon', 'elegance' ),
						'desc' => __( 'Upload your own icon to use.', 'elegance' ),
						'id' => 'custom_icon',
						'default' => '',
						'type' => 'upload',
					),
					array(
						'name' => __( 'Title', 'elegance' ),
						'desc' => __( 'Type out a title to display alongside your icon.', 'elegance' ),
						'id' => 'title',
						'default' => '',
						'type' => 'text',
					),
					array(
						'name' => __( 'Teaser', 'elegance' ),
						'desc' => __( 'Upload your own icon to use.', 'elegance' ),
						'id' => 'content',
						'default' => '',
						'type' => 'textarea',
					),
					array(
						'name' => __( 'Link Text', 'elegance' ),
						'desc' => __( 'If you want a link to display beneath your teaser then type some text here.', 'elegance' ),
						'id' => 'link_text',
						'default' => '',
						'type' => 'text',
					),
					array(
						'name' => __( 'Link Url', 'elegance' ),
						'desc' => __( 'Type out the URL for your link.', 'elegance' ),
						'id' => 'link',
						'default' => '',
						'type' => 'text',
					),
				'shortcode_has_atts' => true,
				)
			);

			return $option;
		}
		
		extract(shortcode_atts(array(
			'type' 	=> '',
			'style'	=> '',
			'custom_icon' 	=> '',
			'title' => '',
			'link_text' => '',
			'link' => '',
		), $atts));
		
		$out = '';
		
		$src = THEME_IMAGES . '/icons/' . $style .'/'. $type . '.png';
		if (!empty($custom_icon)) { $src = $custom_icon; }
		
		$out .= '<div class = "icon_teaser">';
		$out .= '<span class = "icon"><img src = "'.$src.'" alt = ""></span>';
			$out .= '<div class = "icon_text">';
				if (!empty($title)) { $out .= '<h3>'.$title.'</h3>'; }
				if (!empty($content)) { $out .= '<p>'.$content.'</p>'; }
				if (!empty($link)) { $out .= '<p><a class = "icon_teaser_link" href = "'.$link.'">'.$link_text.'</a></p>'; }
			$out .= '</div>';
		$out .= '</div>';
		
		return $out;
	}
	
	/**
	 *
	 */
	static function icon_banner( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {

			$option = array( 
				'name' => __( 'Icon Banners', 'elegance' ),
				'value' => 'icon_banner',
				'options' => array(
					array(
						'name' => __( 'Select Preset Icon', 'elegance' ),
						'desc' => __( 'Select one of our icon presets to use.', 'elegance' ),
						'id' => 'type',
						'default' => '',
						'shortcode' => 'icon_banner',
						'type' => 'icon_preset',
					),
					array(
						'id' => 'style',
						'default' => '',
						'type' => 'hidden',
					),
					array(
						'name' => __( 'Upload Custom Icon', 'elegance' ),
						'desc' => __( 'Upload your own icon to use.', 'elegance' ),
						'id' => 'custom_icon',
						'default' => '',
						'type' => 'upload',
					),
				'shortcode_has_atts' => true,
				)
			);

			return $option;
		}
		
		extract(shortcode_atts(array(
			'type' 	=> '',
			'style'	=> '',
			'custom_icon' 	=> '',
		), $atts));
		
		$src = THEME_IMAGES . '/icons/_banners/'. $type . '.png';
		if (!empty($custom_icon)) { $src = $custom_icon; }
		
		return '<span class = "icon_banner"><span class = "icon"><img src = "'.$src.'" alt = ""></span></span>';
	}

	/**
	 *
	 */
	static function _options( $class ) {
		$shortcode = array();
		
		$class_methods = get_class_methods( $class );
		
		foreach( $class_methods as $method ) {
			if( $method[0] != '_' )
				$shortcode[] = call_user_func(array( &$class, $method ), $atts = 'generator' );
		}
		
		$options = array(
			'name' => __( 'Icons', 'elegance' ),
			'desc' => __( 'Select which Icon type you would like to use.', 'elegance' ),
			'value' => 'icons',
			'options' => $shortcode,
			'shortcode_has_types' => true
		);
		
		return $options;
	}
	
}

?>