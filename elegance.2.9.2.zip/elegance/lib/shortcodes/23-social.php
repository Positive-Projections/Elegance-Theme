<?php
/**
 *
 */
class mysiteSocial {

	/**
	 *  ReTweet button
	 */
	static function tweet( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "Twitter", 'elegance' ),
				"value" => "tweet",
				"options" => array(
					array(
						"name" => __( "Twitter Username", 'elegance' ),
						"id" => "username",
						"desc" => __( 'Type out your twitter username here.  You can find your twitter username by logging into your twitter account.', 'elegance' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Tweet Position", 'elegance' ),
						"id" => "layout",
						"desc" => __( 'Choose whether you want your tweets to display vertically, horizontally, or none at all.', 'elegance' ),
						"default" => "",
						"options" => array(
							"vertical" => __( "Vertical", 'elegance' ),
							"horizontal" => __( "Horizontal", 'elegance' ),
							"none" => __( "None", 'elegance' ),
						),
						"type" => "select"
					),
					array(
						"name" => __( "Custom Text", 'elegance' ),
						"id" => "text",
						"desc" => __( 'This is the text that people will include in their Tweet when they share from your website.', 'elegance' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Custom URL", 'elegance' ),
						"id" => "url",
						"desc" => __( 'By default the URL from your page will be used but you can input a custom URL here.', 'elegance' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Related Users", 'elegance' ),
						"id" => "related",
						"desc" => __( 'You can input another twitter username for recommendation.', 'elegance' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Language", 'elegance' ),
						"id" => "lang",
						"desc" => __( 'Select which language you would like to display the button in.', 'elegance' ),
						"default" => "",
						"options" => array(
							"fr" => __( "French", 'elegance' ),
							"de" => __( "German", 'elegance' ),
							"it" => __( "Italian", 'elegance' ),
							"ja" => __( "Japanese", 'elegance' ),
							"ko" => __( "Korean", 'elegance' ),
							"ru" => __( "Russian", 'elegance' ),
							"es" => __( "Spanish", 'elegance' ),
							"tr" => __( "Turkish", 'elegance' ),
						),
						"type" => "select"
					),
					"shortcode_has_atts" => true,
				)
			);

			return $option;
		}
		
		extract(shortcode_atts(array(
			'layout'        => 'vertical',
			'username'		  => '',
			'text' 			  => '',
			'url'			  => '',
			'related'		  => '',
			'lang'			  => '',
	    	), $atts));
	
		if( is_feed() ) return;
	    	
	    if ($text != '') { $text = "data-text='".$text."'"; }
	    if ($url != '') { $url = "data-url='".$url."'"; }
	    if ($related != '') { $related = "data-related='".$related."'"; }
	    if ($lang != '') { $lang = "data-lang='".$lang."'"; }
		
		$out = '<div class = "mysite_sociable"><a href="http://twitter.com/share" class="twitter-share-button" '.$url.' '.$lang.' '.$text.' '.$related.' data-count="'.$layout.'" data-via="'.$username.'">Tweet</a>';
		$out .= '<script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script></div>';
		
		return $out;
	}
	
	/**
	 *  Facebook Like button
	 */
	static function fblike( $atts = null, $content = null ) {

	    if( $atts == 'generator' ) {
	        $option = array(
	            "name" => __( "Facebook Like", 'elegance' ),
	            "value" => "fblike",
	            "options" => array(
	                array(
	                    "name" => __( "Layout", 'elegance' ),
	                    "id" => "layout",
	                    "desc" => __( 'Choose the layout you would like to use with your facebook button.', 'elegance' ),
	                    "default" => "",
	                    "options" => array(
	                        "standard" => __( "Standard", 'elegance' ),
	                        "box_count" => __( "Box Count", 'elegance' ),
	                        "button_count" => __( "Button Count", 'elegance' ),
	                    ),
	                    "type" => "select"
	                ),
	                array(
	                    "name" => __( "Add send button?", 'elegance' ),
	                    "id" => "send",
	                    "desc" => __( 'Check to add the send button alongside the like button.', 'elegance' ),
	                    'options' => array( 'true' => __( 'Yes', 'elegance' )),
	                    'default' => '',
	                    'type' => 'checkbox'
	                ),
	                array(
	                    "name" => __( "Show Faces?", 'elegance' ),
	                    "id" => "show_faces",
	                    "desc" => __( 'Check to display faces.', 'elegance' ),
	                    'options' => array( 'true' => __( 'Yes', 'elegance' )),
	                    'default' => '',
	                    'type' => 'checkbox'
	                ),
	                array(
	                    "name" => __( "Action", 'elegance' ),
	                    "id" => "action",
	                    "desc" => __( 'This is the text that gets displayed on the button.', 'elegance' ),
	                    "default" => "",
	                    "options" => array(
	                        "like" => __( "Like", 'elegance' ),
	                        "recommend" => __( "Recommend", 'elegance' ),
	                    ),
	                    "type" => "select"
	                ),
	                array(
	                    "name" => __( "Font", 'elegance' ),
	                    "id" => "font",
	                    "desc" => __( 'Select which font you would like to use.', 'elegance' ),
	                    "default" => "",
	                    "options" => array(
	                        "lucida+grande" => __( "Lucida Grande", 'elegance' ),
	                        "arial" => __( "Arial", 'elegance' ),
	                        "segoe+ui" => __( "Segoe Ui", 'elegance' ),
	                        "tahoma" => __( "Tahoma", 'elegance' ),
	                        "trebuchet+ms" => __( "Trebuchet MS", 'elegance' ),
	                        "verdana" => __( "Verdana", 'elegance' ),
	                    ),
	                    "type" => "select"
	                ),
	                array(
	                    "name" => __( "Color Scheme", 'elegance' ),
	                    "id" => "colorscheme",
	                    "desc" => __( 'Select the color scheme you would like to use.', 'elegance' ),
	                    "default" => "",
	                    "options" => array(
	                        "light" => __( "Light", 'elegance' ),
	                        "dark" => __( "Dark", 'elegance' ),
	                    ),
	                    "type" => "select"
	                ),
	                "shortcode_has_atts" => true,
	            )
	        );

	        return $option;
	    }

	    extract(shortcode_atts(array(
	            'layout'        => 'box_count',
	            'width'            => '',
	            'height'        => '',
	            'send'            => false,
	            'show_faces'    => false,
	            'action'        => 'like',
	            'font'            => 'lucida+grande',
	            'colorscheme'    => 'light',
	        ), $atts));

	    if( is_feed() ) return;

	    if ($layout == 'standard') { $width = '450'; $height = '35';  if ($show_faces == 'true') { $height = '80'; } }
	    if ($layout == 'box_count') { $width = '55'; $height = '65'; }
	    if ($layout == 'button_count') { $width = '90'; $height = '20'; }

	    $layout = 'data-layout = "'.$layout.'"';
	    $width = 'data-width = "'.$width.'"';
	    $font = 'data-font = "'.str_replace("+", " ", $font).'"';
	    $colorscheme = 'data-colorscheme = "'.$colorscheme.'"';
	    $action = 'data-action = "'.$action.'"';
	    if ( $show_faces ) { $show_faces = 'data-show-faces = "true"'; } else { $show_faces = ''; }
	    if ( $send ) { $send = 'data-send = "true"'; } else { $send = ''; }

	    $out = '<div class = "mysite_sociable">';
	    $out .= '<div id="fb-root"></div><script>(function(d, s, id) {var js, fjs = d.getElementsByTagName(s)[0];if (d.getElementById(id)) return;js = d.createElement(s); js.id = id;js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";fjs.parentNode.insertBefore(js, fjs);}(document, "script", "facebook-jssdk"));</script>';
	    $out .= '<div class = "fb-like" data-href = "'.get_permalink().'" '.$layout.$width.$font.$colorscheme.$action.$show_faces.$send.'></div>';
	    $out .= '</div>';

	    return $out;
	}
	
	
	/**
	 *  Google +1
	 */
	static function googleplusone( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "Google +1", 'elegance' ),
				"value" => "googleplusone",
				"options" => array(
					array(
						"name" => __( "Size", 'elegance' ),
						"id" => "size",
						"desc" => __( 'Choose how you would like to display the google plus button.', 'elegance' ),
						"default" => "",
						"options" => array(
							"small" => __( "Small", 'elegance' ),
							"standard" => __( "Standard", 'elegance' ),
							"medium" => __( "Medium", 'elegance' ),
							"tall" => __( "Tall", 'elegance' ),
						),
						"type" => "select"
					),
					array(
						"name" => __( "Language", 'elegance' ),
						"id" => "lang",
						"desc" => __( 'Select which language you would like to display the button in.', 'elegance' ),
						"default" => "",
						"options" => array(
							"ar" => __( "Arabic", 'elegance' ),
							"bn" => __( "Bengali", 'elegance' ),
							"bg" => __( "Bulgarian", 'elegance' ),
							"ca" => __( "Catalan", 'elegance' ),
							"zh" => __( "Chinese", 'elegance' ),
							"zh_CN" => __( "Chinese (China)", 'elegance' ),
							"zh_HK" => __( "Chinese (Hong Kong)", 'elegance' ),
							"zh_TW" => __( "Chinese (Taiwan)", 'elegance' ),
							"hr" => __( "Croation", 'elegance' ),
							"cs" => __( "Czech", 'elegance' ),
							"da" => __( "Danish", 'elegance' ),
							"nl" => __( "Dutch", 'elegance' ),
							"en_IN" => __( "English (India)", 'elegance' ),
							"en_IE" => __( "English (Ireland)", 'elegance' ),
							"en_SG" => __( "English (Singapore)", 'elegance' ),
							"en_ZA" => __( "English (South Africa)", 'elegance' ),
							"en_GB" => __( "English (United Kingdom)", 'elegance' ),
							"fil" => __( "Filipino", 'elegance' ),
							"fi" => __( "Finnish", 'elegance' ),
							"fr" => __( "French", 'elegance' ),
							"de" => __( "German", 'elegance' ),
							"de_CH" => __( "German (Switzerland)", 'elegance' ),
							"el" => __( "Greek", 'elegance' ),
							"gu" => __( "Gujarati", 'elegance' ),
							"iw" => __( "Hebrew", 'elegance' ),
							"hi" => __( "Hindi", 'elegance' ),
							"hu" => __( "Hungarian", 'elegance' ),
							"in" => __( "Indonesian", 'elegance' ),
							"it" => __( "Italian", 'elegance' ),
							"ja" => __( "Japanese", 'elegance' ),
							"kn" => __( "Kannada", 'elegance' ),
							"ko" => __( "Korean", 'elegance' ),
							"lv" => __( "Latvian", 'elegance' ),
							"ln" => __( "Lingala", 'elegance' ),
							"lt" => __( "Lithuanian", 'elegance' ),
							"ms" => __( "Malay", 'elegance' ),
							"ml" => __( "Malayalam", 'elegance' ),
							"mr" => __( "Marathi", 'elegance' ),
							"no" => __( "Norwegian", 'elegance' ),
							"or" => __( "Oriya", 'elegance' ),
							"fa" => __( "Persian", 'elegance' ),
							"pl" => __( "Polish", 'elegance' ),
							"pt_BR" => __( "Portugese (Brazil)", 'elegance' ),
							"pt_PT" => __( "Portugese (Portugal)", 'elegance' ),
							"ro" => __( "Romanian", 'elegance' ),
							"ru" => __( "Russian", 'elegance' ),
							"sr" => __( "Serbian", 'elegance' ),
							"sk" => __( "Slovak", 'elegance' ),
							"sl" => __( "Slovenian", 'elegance' ),
							"es" => __( "Spanish", 'elegance' ),
							"sv" => __( "Swedish", 'elegance' ),
							"gsw" => __( "Swiss German", 'elegance' ),
							"ta" => __( "Tamil", 'elegance' ),
							"te" => __( "Telugu", 'elegance' ),
							"th" => __( "Thai", 'elegance' ),
							"tr" => __( "Turkish", 'elegance' ),
							"uk" => __( "Ukranian", 'elegance' ),
							"vi" => __( "Vietnamese", 'elegance' ),
						),
						"type" => "select"
					),
					"shortcode_has_atts" => true,
				)
			);

			return $option;
		}
		
		extract(shortcode_atts(array(
				'size'			=> '',
				'lang'			=> '',
	    ), $atts));
		
		if( is_feed() ) return;
		
	    if ($size != '') { $size = "size='".$size."'"; }
	    if ($lang != '') { $lang = "{lang: '".$lang."'}"; }
	    
		$out = '<div class = "mysite_sociable"><script type="text/javascript" src="https://apis.google.com/js/plusone.js">'.$lang.'</script>';
		$out .= '<g:plusone '.$size.'></g:plusone></div>';
	    		
		return $out;
	}
	
	/**
	 *  Digg button
	 */
	static function digg( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "Digg", 'elegance' ),
				"value" => "digg",
				"options" => array(
					array(
						"name" => __( "Layout", 'elegance' ),
						"id" => "layout",
						"desc" => __( 'Choose how you would like to display the digg button.', 'elegance' ),
						"default" => "",
						"options" => array(
							"DiggWide" => __( "Wide", 'elegance' ),
							"DiggMedium" => __( "Medium", 'elegance' ),
							"DiggCompact" => __( "Compact", 'elegance' ),
							"DiggIcon" => __( "Icon", 'elegance' ),
						),
						"type" => "select"
					),
					array(
						"name" => __( "Custom URL", 'elegance' ),
						"id" => "url",
						"desc" => __( 'In case you wish to use a different URL you can input it here.', 'elegance' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Custom Title", 'elegance' ),
						"id" => "title",
						"desc" => __( 'In case you wish to use a different title you can input it here.', 'elegance' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Article Type", 'elegance' ),
						"id" => "type",
						"desc" => __( 'You can set the article type here for digg.<br /><br />For example if you wanted to set it in the gaming or entertainment topics then you would type this, "gaming, entertainment".', 'elegance' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Custom Description", 'elegance' ),
						"id" => "description",
						"desc" => __( 'You can set a custom description to be displayed within digg here.', 'elegance' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Related Stories", 'elegance' ),
						"id" => "related",
						"desc" => __( 'This option allows you to specify whether links to related stories should be present in the pop up window that may appear when users click the button.', 'elegance' ),
						"default" => "",
						"options" => array(
							"true" => __( "Disable related stories?", 'elegance' ),
						),
						"type" => "checkbox"
					),
					"shortcode_has_atts" => true,
				)
			);			
			
			return $option;
		}
				
		extract(shortcode_atts(array(
			'layout'        => 'DiggMedium',
			'url'			=> get_permalink(),
			'title'			=> '',
			'type'			=> '',
			'description'	=> '',
			'related'		=> '',
	    	), $atts));
	
		if( is_feed() ) return;
	    
	    if ($title != '') { $title = "&title='".$title."'"; }
	    if ($type != '') { $type = "rev='".$type."'"; }
	    if ($description != '') { $description = "<span style = 'display: none;'>".$description."</span>"; }
	    if ($related != '') { $related = "&related=no"; }
	    	
		$out = '<div class = "mysite_sociable"><a class="DiggThisButton '.$layout.'" href="http://digg.com/submit?url='.$url.$title.$related.'"'.$type.'>'.$description.'</a>';
		$out .= '<script type = "text/javascript" src = "http://widgets.digg.com/buttons.js"></script></div>';
		
		return $out;
	}
	
	/**
	 *  Stumbleupon button
	 */
	static function stumbleupon( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "Stumbleupon", 'elegance' ),
				"value" => "stumbleupon",
				"options" => array(
					array(
						"name" => __( "Layout", 'elegance' ),
						"id" => "layout",
						"desc" => __( 'Choose how you would like to display the stumbleupon button.', 'elegance' ),
						"default" => "",
						"options" => array(
							"1" => __( "Style 1", 'elegance' ),
							"2" => __( "Style 2", 'elegance' ),
							"3" => __( "Style 3", 'elegance' ),
							"4" => __( "Style 4", 'elegance' ),
							"5" => __( "Style 5", 'elegance' ),
							"6" => __( "Style 6", 'elegance' ),
						),
						"type" => "select"
					),
					array(
						"name" => __( "Custom URL", 'elegance' ),
						"id" => "url",
						"desc" => __( 'You can set a custom URL to be displayed within stumbleupon here.', 'elegance' ),
						"default" => "",
						"type" => "text"
					),
					"shortcode_has_atts" => true,
				)
			);			
			
			return $option;
		}
		
		extract(shortcode_atts(array(
			'layout'        => '5',
			'url'			=> '',
	    	), $atts));
	
		if( is_feed() ) return;
	    	
	    if ($url != '') { $url = "&r=".$url; }
	    	
		return '<div class = "mysite_sociable"><script src="http://www.stumbleupon.com/hostedbadge.php?s='.$layout.$url.'"></script></div>';
	}
	
	/**
	 *  Reddit button
	 */
	static function reddit( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "Reddit", 'elegance' ),
				"value" => "reddit",
				"options" => array(
					array(
						"name" => __( "Layout", 'elegance' ),
						"id" => "layout",
						"desc" => __( 'Choose how you would like to display the reddit button.', 'elegance' ),
						"default" => "",
						"options" => array(
							"1" => __( "Style 1", 'elegance' ),
							"2" => __( "Style 2", 'elegance' ),
							"3" => __( "Style 3", 'elegance' ),
							"4" => __( "Style 4", 'elegance' ),
							"5" => __( "Style 5", 'elegance' ),
							"6" => __( "Style 6", 'elegance' ),
							"7" => __( "Interactive 1", 'elegance' ),
							"8" => __( "Interactive 2", 'elegance' ),
							"9" => __( "Interactive 3", 'elegance' ),
						),
						"type" => "select"
					),
					array(
						"name" => __( "Custom URL", 'elegance' ),
						"id" => "url",
						"desc" => __( 'You can set a custom URL to be displayed with your button instead of the current page.', 'elegance' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Custom Title", 'elegance' ),
						"id" => "title",
						"desc" => __( 'If using the interactive buttons you can specify a custom title to use here.', 'elegance' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Styling", 'elegance' ),
						"id" => "disablestyle",
						"desc" => __( 'Checking this will disable the reddit styling used for the button.', 'elegance' ),
						"default" => "",
						"options" => array(
							"true" => __( "Disable reddit styling?", 'elegance' ),
						),
						"type" => "checkbox"
					),
					array(
						"name" => __( "Target", 'elegance' ),
						"id" => "target",
						"desc" => __( 'Select the target for this button.', 'elegance' ),
						"default" => "",
						"options" => array(
							"true" => __( "Display in new window?", 'elegance' ),
						),
						"type" => "checkbox"
					),
					array(
						"name" => __( "Community", 'elegance' ),
						"id" => "community",
						"desc" => __( 'If using the interactive buttons you can specify a community to target here.', 'elegance' ),
						"default" => "",
						"type" => "text"
					),
					"shortcode_has_atts" => true,
				)
			);			
			
			return $option;
		}
		
		extract(shortcode_atts(array(
			'layout'        => '8',
			'url'			=> '',
			'disablestyle'	=> '',
			'target'		=> '',
			'community'		=> '',
			'title'			=> '',
	    	), $atts));
	
		if( is_feed() ) return;
	    	
	    if ($disablestyle != '') { $disablestyle = "&styled=off"; }
	    if ($target != '') { $target = "&newwindow=1"; }
	    if ($layout == '7' || $layout == '8' || $layout == '9') { $url = "reddit_url='".$url."';"; } else { if ($url != '') { $url = "&url='".$url."'"; } }
	    if ($title != '') { $title = "reddit_title='".$title."';"; }
	    if ($community != '') { $community = "reddit_target='".$community."';"; }
	    if ($layout == '7' || $layout == '8' || $layout == '9') { $target = "reddit_newwindow='1';"; }
	    	
		switch ($layout)
		{
			case 1: return '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/buttonlite.js?i=0'.$disablestyle.$url.$target.'"></script></div>'; break;
			case 2: return '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/buttonlite.js?i=1'.$disablestyle.$url.$target.'"></script></div>'; break;		
			case 3: return '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/buttonlite.js?i=2'.$disablestyle.$url.$target.'"></script></div>'; break;		
			case 4: return '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/buttonlite.js?i=3'.$disablestyle.$url.$target.'"></script></div>'; break;		
			case 5: return '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/buttonlite.js?i=4'.$disablestyle.$url.$target.'"></script></div>'; break;		
			case 6: return '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/buttonlite.js?i=5'.$disablestyle.$url.$target.'"></script></div>'; break;	
			case 7: $out = '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/static/button/button1.js"></script>'; 
					$out .= '<script type = "text/javascript">'.$url.$title.$community.$target.'</script></div>';
					return $out; break;
			case 8: $out = '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/static/button/button2.js"></script>';
					$out .= '<script type = "text/javascript">'.$url.$title.$community.$target.'</script></div>';
					return $out; break;
			case 9: $out = '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/static/button/button3.js"></script>'; 
					$out .= '<script type = "text/javascript">'.$url.$title.$community.$target.'</script></div>';
					return $out; break;	
		}
	}
	
	/**
	 *  LinkedIn button
	 */
	static function linkedin( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "LinkedIn", 'elegance' ),
				"value" => "linkedin",
				"options" => array(
					array(
						"name" => __( "Layout", 'elegance' ),
						"id" => "layout",
						"desc" => __( 'Choose how you would like to display the linkedin button.', 'elegance' ),
						"default" => "",
						"options" => array(
							"1" => __( "Style 1", 'elegance' ),
							"2" => __( "Style 2", 'elegance' ),
							"3" => __( "Style 3", 'elegance' ),
						),
						"type" => "select"
					),
					array(
						"name" => __( "Custom URL", 'elegance' ),
						"id" => "url",
						"desc" => __( 'You can set a custom URL to be displayed within linkedin here.', 'elegance' ),
						"default" => "",
						"type" => "text"
					),
					"shortcode_has_atts" => true,
				)
			);			
			
			return $option;
		}
		
		extract(shortcode_atts(array(
			'layout'        => '3',
			'url'			=> '',
	    	), $atts));
	
		if( is_feed() ) return;
	    	
	    if ($url != '') { $url = "data-url='".$url."'"; }
	    if ($layout == '2') { $layout = 'right'; }
		if ($layout == '3') { $layout = 'top'; }
	    	
		return '<div class = "mysite_sociable"><script type="text/javascript" src="http://platform.linkedin.com/in.js"></script><script type="in/share" data-counter = "'.$layout.'" '.$url.'></script></div>';
	}
	
	/**
	 *  Delicious button
	 */
	static function delicious( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "Delicious", 'elegance' ),
				"value" => "delicious",
				"options" => array(
					array(
						"name" => __( "Custom Text", 'elegance' ),
						"id" => "text",
						"desc" => __( 'You can set some text to display alongside your delicious button.', 'elegance' ),
						"default" => "",
						"type" => "text"
					),
					"shortcode_has_atts" => true,
				)
			);			
			
			return $option;
		}
		
		extract(shortcode_atts(array(
			'text'			=> '',
	    ), $atts));
	
		if( is_feed() ) return;
	    	
		return '<div class = "mysite_sociable"><img src="http://www.delicious.com/static/img/delicious.small.gif" height="10" width="10" alt="Delicious" />&nbsp;<a href="http://www.delicious.com/save" onclick="window.open(&#39;http://www.delicious.com/save?v=5&noui&jump=close&url=&#39;+encodeURIComponent(location.href)+&#39;&title=&#39;+encodeURIComponent(document.title), &#39;delicious&#39;,&#39;toolbar=no,width=550,height=550&#39;); return false;">'.$text.'</a></div>';
	}
	
	/**
	 *  Pinterest button
	 */
	static function pinterest( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "Pinterest", 'elegance' ),
				"value" => "pinterest",
				"options" => array(
					array(
						"name" => __( "Description", 'elegance' ),
						"id" => "text",
						"desc" => __( 'You can set some text to display alongside your Pinterest button.', 'elegance' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Layout", 'elegance' ),
						"id" => "layout",
						"desc" => __( 'Choose how you would like to display the Pinterest button.', 'elegance' ),
						"default" => "",
						"options" => array(
							"horizontal" => __( "Horizontal", 'elegance' ),
							"vertical" => __( "Vertical", 'elegance' ),
							"none" => __( "None", 'elegance' ),
						),
						"type" => "select"
					),
					array(
						"name" => __( "Image URL", 'elegance' ),
						"id" => "image",
						"desc" => __( 'Paste the URL of the image you want to be pinned here.', 'elegance' ),
						"default" => "",
						"type" => "text",
					),
					array(
						"name" => __( "Auto Prompt", 'elegance' ),
						"id" => "prompt",
						"desc" => __( 'Check this if you wish to have a prompt display to select your image when clicking on the Pinterest button. This will disable the count bubble.', 'elegance' ),
						"options" => array( "true" => __( "Use Auto Prompt", 'elegance' ) ),  
						"default" => "",
						"type" => "checkbox",
					),
					"shortcode_has_atts" => true,
				)
			);			
			
			return $option;
		}
		
		extract(shortcode_atts(array(
			'text'			=> '',
			'layout'		=> '',
			'image'			=> '',
			'url'			=> '',
			'prompt'	=> '',
	    ), $atts));
	
		if( is_feed() ) return;
	    	
		if ($url == '') { $url = get_permalink(); }
		if ($layout == '') { $layout = 'horizontal'; }
			
		$out = '<div class = "mysite_sociable"><a href="http://pinterest.com/pin/create/button/?url='.$url.'&media='.$image.'&description='.$text.'" class="pin-it-button" count-layout="'.$layout.'">Pin It</a>';
		$out .= '<script type="text/javascript" src="http://assets.pinterest.com/js/pinit.js"></script></div>';
		
		if ( $prompt ) {
			$out = '<div class = "mysite_sociable"><a title="Pin It on Pinterest" class="pin-it-button" href="javascript:void(0)">pin it</a>';
			$out .= '<script type = "text/javascript">';
			$out .= 'jQuery(document).ready(function(){';
				$out .= 'jQuery(".pin-it-button").click(function(event) {';
				$out .= 'event.preventDefault();';
				$out .= 'jQuery.getScript("http://assets.pinterest.com/js/pinmarklet.js?r=" + Math.random()*99999999);';
				$out .= '});';
			$out .= '});';
			$out .= '</script>';
			$out .= '<style type = "text/css">a.pin-it-button {position: absolute;background: url(http://assets.pinterest.com/images/pinit6.png);font: 11px Arial, sans-serif;text-indent: -9999em;font-size: .01em;color: #CD1F1F;height: 20px;width: 43px;background-position: 0 -7px;}a.pin-it-button:hover {background-position: 0 -28px;}a.pin-it-button:active {background-position: 0 -49px;}</style></div>';
		}
			
		return $out;
	}
	
	/**
	 *
	 */
	static function _options( $class ) {
		$shortcode = array();
		
		$class_methods = get_class_methods( $class );
		
		foreach( $class_methods as $method ) {
			if( $method[0] != '_' )
				$shortcode[] = call_user_func(array( &$class, $method ), $atts = 'generator' );
		}
		
		$options = array(
			"name" => __( 'Social', 'elegance' ),
			'desc' => __( 'Choose which type of social button you wish to use.', 'elegance' ),
			"value" => "social",
			"options" => $shortcode,
			"shortcode_has_types" => true
		);
		
		return $options;
	}
}

?>