<?php
/**
 *
 */
class mysiteFrames {
	
	/**
	 *
	 */
	static function image_frame( $atts = null, $content = null ) {
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Image Frames', 'elegance' ),
				'value' => 'image_frame',
				'options' => array(
					array(
						'name' => __( 'Type', 'elegance' ),
						'desc' => __( 'Choose which type of frame you wish to use.', 'elegance' ),
						'id' => 'style',
						'default' => '',
						'options' => array(
							'border' => __( 'Transparent Border', 'elegance' ),
							'reflect' => __( 'Reflection', 'elegance' ),
							'framed' => __( 'Framed', 'elegance' ),
							'shadow' => __( 'Shadow', 'elegance' ),
							'reflect_shadow' => __( 'Reflection + Shadow', 'elegance' ),
							'framed_shadow' => __( 'Framed + Shadow', 'elegance' )
						),
						'type' => 'select'
					),
					array(
						'name' => __( 'Image URL', 'elegance' ),
						'desc' => __( 'You can upload your image that you wish to use here.', 'elegance' ),
						'id' => 'content',
						'default' => '',
						'type' => 'upload',
					),
					array(
						'name' => __( 'Align <small>(optional)</small>', 'elegance' ),
						'desc' => __( 'Set the alignment for your image here.<br /><br />Your image will float along the center, left or right hand sides depending on your choice.', 'elegance' ),
						'id' => 'align',
						'default' => '',
						'options' => array(
							'left' => __( 'left', 'elegance' ),
							'right' => __( 'right', 'elegance' ),
							'center' => __( 'center', 'elegance' )
						),
						'type' => 'select'
					),
					array(
						'name' => __( 'Alt Attribute <small>(optional)</small>', 'elegance' ),
						'desc' => __( 'Type the alt text that you would like to display with your image here.', 'elegance' ),
						'id' => 'alt',
						'default' => '',
						'type' => 'text'
					),
					array(
						'name' => __( 'Title Attribute <small>(optional)</small>', 'elegance' ),
						'desc' => __( 'Type the title text that you would like to display with your image here.', 'elegance' ),
						'id' => 'title',
						'default' => '',
						'type' => 'text'
					),
					array(
						'name' => __( 'Image Height <small>(optional)</small>', 'elegance' ),
						'desc' => __( 'You can set the image height here.  Leave this blank if you do not want to resize your image.', 'elegance' ),
						'id' => 'height',
						'default' => '',
						'type' => 'text'
					),
					array(
						'name' => __( 'Image Width <small>(optional)</small>', 'elegance' ),
						'desc' => __( 'You can set the image width here.  Leave this blank if you do not want to resize your image.', 'elegance' ),
						'id' => 'width',
						'default' => '',
						'type' => 'text'
					),
				'shortcode_has_atts' => true
				)
			);
			
			return $option;
		}
		
		extract(shortcode_atts(array(
	        'style'		  => '',
			'align'		  => '',
			'alt'		  => '',
			'title'		  => '',
			'height'	  => '',
			'width'		  => '',
			'link_to' 	  => 'true',
			'prettyphoto' => 'true'
		), $atts));
		
		global $wp_query, $mysite;
	
		$out = '';
		
		$effect = trim( $style );
		$effect = ( !empty( $effect ) ) ? $effect : 'framed';
		$align = ( $align == 'left' ? ' alignleft' : ( $align == 'right' ? ' alignright' : ( $align == 'center' ? ' aligncenter' : ' alignleft' ) ) );
		$class = ( $effect == 'reflect' ? "reflect{$align}" : ( $effect == 'reflect_shadow' ? 'reflect' : ( $effect == 'framed' ? "framed{$align}" : ( $effect == 'framed_shadow' ? 'framed' : '' ) ) ) );
		
		$width = ( !empty( $width ) ) ? trim(str_replace(' ', '', str_replace('px', '', $width ) ) ) : '';
		$height = ( !empty( $height ) ) ? trim(str_replace(' ', '', str_replace('px', '', $height ) ) ) : '';
		
		if( preg_match( '!https?://.+\.(?:jpe?g|png|gif)!Ui', $content, $matches ) ) {
			
			$new_url = mr_image_resize($matches[0], $width, $height, true);
			$rel = '';
			if( $prettyphoto == 'true' ){
				$rel = 'rel="prettyPhoto"';
			} else{
				$rel = '';
			}
			
			
			$link_html = '';
			$link_html_end = '';
			if($link_to == 'true'){
				$link_html = '<a href="'.$matches[0].'" '.$rel.'>';
				$link_html_end = '</a>';
			}
			
			$out .= $link_html.'<img class="'.$class.'" src="'.$new_url.'" alt="'.$alt.'">'.$link_html_end;
			// removed code for image resize since 2.9.1
			/*$out .= mysite_display_image(array(
				'src' 			=> $matches[0],
				'alt' 			=> $alt,
				'title' 		=> $title,
				'class' 		=> $class,
				'height' 		=> $height,
				'width'			=> $width,
				'link_to' 		=> ( $link_to == 'true' ? $matches[0] : false ),
				'prettyphoto'	=> ( $prettyphoto == 'true' ? true : false ),
				'align'			=> $align,
				'effect' 		=> $effect,
				'wp_resize' 	=> ( mysite_get_setting( 'image_resize_type' ) == 'wordpress' ? true : false )
			));*/
		}
		
		return $out;
	}
	
	/**
	 *
	 */
	static function _options( $class ) {
		$shortcode = array();

		$class_methods = get_class_methods( $class );

		foreach( $class_methods as $method ) {
			if( $method[0] != '_' )
				$shortcode[] = call_user_func(array( &$class, $method ), $atts = 'generator' );
		}

		$options = array(
			'name' => __( 'Image Frames', 'elegance' ),
			'value' => 'image_frame',
			'options' => $shortcode
		);

		return $options;
	}

}

?>