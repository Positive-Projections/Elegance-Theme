<?php
/**
 *
 */
class mysiteLists {
	
	/**
	 *
	 */
	static function fancy_list( $atts = null, $content = null ) {
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Fancy List', 'elegance' ),
				'value' => 'fancy_list',
				'options' => array(
					array(
						'name' => __( 'Style', 'elegance' ),
						'desc' => __( 'Choose the style of list that you wish to use. Each one has a different icon.', 'elegance' ),
						'id' => 'style',
						'default' => '',
						'options' => array(
							'arrow_list' => __( 'Arrow List', 'elegance' ),
							'bullet_list' => __( 'Bullet List', 'elegance' ),
							'check_list' => __( 'Check List', 'elegance' ),
							'circle_arrow' => __( 'Circle Arrow', 'elegance' ),
							'triangle_arrow' => __( 'Triangle Arrow', 'elegance' ),
							'comment_list' => __('Comment List', 'elegance' ),
							'minus_list' => __( 'Minus List', 'elegance' ),
							'plus_list' => __( 'Plus List', 'elegance' ),
							'star_list' => __( 'Star List', 'elegance' )
						),
						'type' => 'select'
					),
					array(
						'name' => __( 'List Html', 'elegance' ),
						'desc' => __( 'Type out the content of your list.  You need to use the &#60;ul&#62; and &#60;li&#62; elements when typing out your list content.', 'elegance' ),
						'id' => 'content',
						'default' => '',
						'type' => 'textarea',
						'return' => true
					),
					array(
						'name' => __( 'Color Variation <small>(optional)</small>', 'elegance' ),
						'desc' => __( 'Choose one of our predefined color skins to use with your list.', 'elegance' ),
						'id' => 'variation',
						'default' => '',
						'target' => 'color_variations',
						'type' => 'select'
					),
				'shortcode_has_atts' => true,
				'shortcode_carriage_return' => true
				)
			);
			
			return $option;
		}
		
		extract(shortcode_atts(array(
			'style'     => '',
			'variation'	=> '',
	    ), $atts));
	
		$style = ( $style ) ? trim( $style ) : 'arrow_list';
	
		$variation = ( $variation ) ? ' ' . trim( $variation ) . '_sprite' : '';

		$content = str_replace( '<ul>', '<ul class="fancy_list">', $content );
		$content = str_replace( '<li>', '<li class="' . $style . $variation . '">', $content );
	
		return mysite_remove_wpautop( $content );
	}
	
	/**
	 *
	 */
	static function fancy_numbers( $atts = null, $content = null ) {
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Fancy Numbers', 'elegance' ),
				'value' => 'fancy_numbers',
				'options' => array(
					array(
						'name' => __( 'List Html', 'elegance' ),
						'desc' => __( 'Type out the content of your list.  You need to use the &#60;ul&#62; and &#60;li&#62; elements when typing out your list content.', 'elegance' ),
						'id' => 'content',
						'default' => '',
						'type' => 'textarea',
						'return' => true
					),
					array(
						'name' => __( 'Color Variation <small>(optional)</small>', 'elegance' ),
						'desc' => __( 'Choose one of our predefined color skins to use with your list.', 'elegance' ),
						'id' => 'variation',
						'default' => '',
						'target' => 'color_variations',
						'type' => 'select'
					),
				'shortcode_has_atts' => true,
				'shortcode_carriage_return' => true
				)
			);
			
			return $option;
		}
		
		extract(shortcode_atts(array(
			'css' 		=> '',
			'classes' 	=> '',
			'variation'	=> '',
		), $atts));
		
		$classes = '';
	
		if ( !empty( $css ) )
			$css = ' style="' . $css . '"';
			
		if ( !empty( $classes ) )
			$classes .= ' ' . $classes;
			
		if ( !empty( $variation ) )
			$classes .= ' ' . $variation . '_numbers';

		$content = str_replace( '<ol>', '<ol class="fancy_numbers' . $classes .'"' . $css . '>', $content );
	
		return mysite_remove_wpautop( do_shortcode( $content ) );
	}

	/**
	 *
	 */
	static function squeeze_list( $atts = null, $content = null ) {
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Squeeze List', 'elegance' ),
				'value' => 'squeeze_list',
				'options' => array(
					array(
						'name' => __( 'Style', 'elegance' ),
						'desc' => __( 'Choose the style of the squeeze list that you wish to use. Each one has a different icon.', 'elegance' ),
						'id' => 'style',
						'default' => '',
						'options' => array(
							'checkmark_list' => __( 'Checkmark List', 'elegance' ),
							'arrow_list' => __( 'Arrow List', 'elegance' ),
							'alert_list' => __( 'Alert List', 'elegance' ),
							'info_list' => __( 'Info Arrow', 'elegance' ),
							'no_list' => __( 'No Arrow', 'elegance' ),
							'plus_list' => __('Plus List', 'elegance' )
						),
						'type' => 'select'
					),
					array(
						'name' => __( 'List Html', 'elegance' ),
						'desc' => __( 'Type out the content of your list. You need to use the &#60;ul&#62; and &#60;li&#62; elements when typing out your list content.', 'elegance' ),
						'id' => 'content',
						'default' => '',
						'type' => 'textarea',
						'return' => true
					),
				'shortcode_has_atts' => true,
				'shortcode_carriage_return' => true
				)
			);

			return $option;
		}

		extract(shortcode_atts(array(
			'style'     => '',
			'css' 		=> '',
			'classes' 	=> '',
	    ), $atts));

		$style = ( $style ) ? ' ' . trim( $style ) : ' checkmark_list';

		if ( !empty( $css ) )
			$css = ' style="' . $css . '"';

		if ( !empty( $classes ) )
			$classes = ' ' . $classes;

		$content = str_replace( '<ul>', '<ul class="squeeze_list' . $style . $classes .'"' . $css . '>', $content );

		return mysite_remove_wpautop( do_shortcode( $content ) );
	}
	
	/**
	 *
	 */
	static function _options( $class ) {
		$shortcode = array();
		
		$class_methods = get_class_methods( $class );
		
		foreach( $class_methods as $method ) {
			if( $method[0] != '_' )
				$shortcode[] = call_user_func(array( &$class, $method ), $atts = 'generator' );
		}
		
		$options = array(
			'name' => __( 'Lists', 'elegance' ),
			'value' => 'lists',
			'options' => $shortcode,
			'shortcode_has_types' => true
		);
		
		return $options;
	}
	
}

?>