<?php
/**
 *
 */
class mysiteMiscellaneous {

	/**
	 *
	 */
	static function fancy_amp( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Fancy Amp', 'elegance' ),
				'value' => 'fancy_amp'
			);

			return $option;
		}
		
		return '<span class="fancy_amp">&amp;</span>';
	}

	/**
	 *
	 */
	static function divider( $atts = null, $content = null, $code = null ) {
		
		if( $atts == 'generator' ) {
			$option = array(
				'name' => __( 'Divider', 'elegance' ),
				'value' => 'divider'
			);

			return $option;
		}
			
		return '<div class="divider"></div>';
	}
	
	/**
	 *
	 */
	static function divider_top( $atts = null, $content = null, $code = null ) {
		
		if( $atts == 'generator' ) {
			$option = array(
				'name' => __( 'Divider Top', 'elegance' ),
				'value' => 'divider_top'
			);

			return $option;
		}
			
		return '<div class="divider top"><a href="#">' . __( 'Top', 'elegance' ) . '</a></div>';
	}
	
	/**
	 *
	 */
	static function clearboth( $atts = null, $content = null, $code = null ) {
		
		if( $atts == 'generator' ) {
			$option = array(
				'name' => __( 'Clearboth', 'elegance' ),
				'value' => 'clearboth'
			);

			return $option;
		}
			
		return '<div class="clearboth"></div>';
	}
	
	/**
	 *
	 */
	static function div( $atts = null, $content = null, $code = null ) {
		$option = array( 
			'name' => __( 'Div', 'elegance' ),
			'value' => 'div',
			'options' => array(
				array(
					'name' => __( 'Class', 'elegance' ),
					'desc' => __( 'Type in the name of the class you wish to assign to this div.', 'elegance' ),
					'id' => 'class',
					'default' => '',
					'type' => 'text'
				),
				array(
					'name' => __( 'Style', 'elegance' ),
					'desc' => __( 'You can set a custom style here for your div.', 'elegance' ),
					'id' => 'style',
					'default' => '',
					'type' => 'text'
				),
				array(
					'name' => __( 'Content', 'elegance' ),
					'desc' => __( 'Type in the content that you wish to display inside this div.', 'elegance' ),
					'id' => 'content',
					'default' => '',
					'type' => 'textarea'
				),
			'shortcode_has_atts' => true,
			)
		);
		
		if( $atts == 'generator' )
			return $option;
			
		extract(shortcode_atts(array(
			'style'      => '',
			'class'      => '',
	    	), $atts));

	   return '<div class="' . $class . '" style="' . $style . '">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function span( $atts = null, $content = null, $code = null ) {
		$option = array( 
			'name' => __( 'Span', 'elegance' ),
			'value' => 'span'
		);
		
		if( $atts == 'generator' )
			return $option;
			
		extract(shortcode_atts(array(
			'style'      => '',
			'class'      => '',
	    	), $atts));

	   return '<span class="' . $class . '" style="' . $style . '">' . mysite_remove_wpautop( $content ) . '</span>';
	}
	
	/**
	 *
	 */
	static function teaser( $atts = null, $content = null ) {

		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Teaser', 'elegance' ),
				'value' => 'teaser'
			);

			return $option;
		}

		return '<p class="teaser"><span>' . mysite_remove_wpautop( $content ) . '</span></p>';
	}
	
	/**
	 *
	 */
	static function hidden( $atts = null, $content = null ) {

		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Hidden', 'elegance' ),
				'value' => 'hidden'
			);

			return $option;
		}

		return '<div class="hidden">' . mysite_remove_wpautop( $content ) . '</div>';
	}

	/**
	 *
	 */
	static function margin10( $atts = null, $content = null ) {
			
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin10', 'elegance' ),
				'value' => 'margin10'
			);

			return $option;
		}
			
		return '<div class="margin10">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin20( $atts = null, $content = null ) {

		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin20', 'elegance' ),
				'value' => 'margin20'
			);

			return $option;
		}
			
		return '<div class="margin20">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin30( $atts = null, $content = null ) {
			
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin30', 'elegance' ),
				'value' => 'margin30'
			);

			return $option;
		}
			
		return '<div class="margin30">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin40( $atts = null, $content = null ) {
			
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin40', 'elegance' ),
				'value' => 'margin40'
			);

			return $option;
		}
			
		return '<div class="margin40">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin50( $atts = null, $content = null ) {
			
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin50', 'elegance' ),
				'value' => 'margin50'
			);

			return $option;
		}
		
		return '<div class="margin50">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin60( $atts = null, $content = null ) {

		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin60', 'elegance' ),
				'value' => 'margin60'
			);

			return $option;
		}
			
		return '<div class="margin60">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin70( $atts = null, $content = null ) {
			
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin70', 'elegance' ),
				'value' => 'margin70'
			);

			return $option;
		}
			
		return '<div class="margin70">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin80( $atts = null, $content = null ) {
			
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin80', 'elegance' ),
				'value' => 'margin80'
			);

			return $option;
		}
			
		return '<div class="margin80">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin90( $atts = null, $content = null ) {
			
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin90', 'elegance' ),
				'value' => 'margin90'
			);

			return $option;
		}
		
		return '<div class="margin90">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function mobile_only( $atts = null, $content = null ) {
		
		$option = array( 
			'name' => __( 'Mobile Only', 'elegance' ),
			'value' => 'mobile_only',
			'options' => array(
				array(
					'name' => __( 'Content', 'elegance' ),
					'desc' => __( 'Type in the content that you wish to display on a mobile device only.', 'elegance' ),
					'id' => 'content',
					'default' => '',
					'type' => 'textarea'
				),
			'shortcode_has_atts' => true,
			)
		);
		
		if( $atts == 'generator' )
			return $option;
			
		extract(shortcode_atts(array(
		), $atts));

		global $mysite;

		if( !isset( $mysite->mobile ) )
			$content = '';

		return $content;
	}

	/**
	 *
	 */
	static function _options( $class ) {
		$shortcode = array();
		
		$class_methods = get_class_methods( $class );
		
		foreach( $class_methods as $method ) {
			if( $method[0] != '_' )
				$shortcode[] = call_user_func(array( &$class, $method ), $atts = 'generator' );
		}
		
		$options = array(
			'name' => __( 'Miscellaneous', 'elegance' ),
			'desc' => __( 'Select which Miscellaneous shortcode you wish to use.', 'elegance' ),
			'value' => 'miscellaneous',
			'options' => $shortcode,
			'shortcode_has_types' => true
		);
		
		return $options;
	}
	
}

?>