<?php
/**
 *
 */
function mysite_get_post_image( $args = array() ) {
	global $mysite;
	
	$defaults = array(
		'index' => '',
		'column' => '',
		'thumb' => '',
		'link_class' => '',
		'preload' => ( isset( $mysite->mobile ) ? false : true ),
		'video_controls' => false,
		'echo' => true,
		'featured_post' => false
	);
	
	$args = wp_parse_args( $args, $defaults );
	
	extract( $args );
	
	if( !empty( $video ) )
		$video = mysite_video( array( 'url' => $video, 'width' => $width, 'height' => $height, 'parse' => true, 'video_controls' => $video_controls ) );
		
	if( empty( $video ) )
	{
		$post_thumbnail_id = get_post_thumbnail_id();

		$auto_img = mysite_get_setting( 'auto_img' );

		if ( ( empty( $post_thumbnail_id ) ) && ( $auto_img[0] ) ) {
			$image = mysite_image_by_attachment();
			if( $image ) {
				$image[0] = $image['url'];
				$alt = $image['alt'];
			} else {
				if( !empty( $placeholder ) )
					$image[0] = THEME_IMAGES_ASSETS . '/post_thumb.png';
				else
					return false;
			}
			
		} elseif( empty( $post_thumbnail_id ) && !empty( $placeholder ) ) {
				$image[0] = THEME_IMAGES_ASSETS . '/post_thumb.png';
				
		} elseif( empty( $post_thumbnail_id ) ) {
			
			return false;
		}

		if( !empty( $post_thumbnail_id ) )
			$image = wp_get_attachment_image_src( $post_thumbnail_id, '' );

		$link_to = ( isset( $link_to ) ? $link_to : ( !empty( $args['video'] ) ? $args['video'] : ( ( is_single() || is_page() ) && empty( $placeholder ) ? $image[0] : get_permalink() ) ) );
		$prettyphoto = ( isset( $prettyphoto ) ? $prettyphoto : ( ( is_single() || is_page() ) && empty( $placeholder ) ? true : false ) );
		$image_tags = mysite_post_image_tags( $post_thumbnail_id, get_the_ID() );
		
		$img_args = array(
			'src' => $image[0],
			'alt' => ( isset( $alt ) ? $alt : $image_tags['alt'] ),
			'title' => $image_tags['title'],
			'height' => $height,
			'width' => $width,
			'class' => 'hover_fade_js',
			'link_to' => $link_to,
			'prettyphoto' => $prettyphoto,
			'link_class' => $link_class,
			'preload' => $preload,
			'portfolio_full' => ( !empty( $portfolio_full ) ? true : false ),
			'wp_resize' => ( !empty( $wp_resize ) ? true : false )
			
		);
		
		$rel = '';
		if( $prettyphoto == true ){
			$rel = 'rel="prettyPhoto"';
		} else{
			$rel = '';
		}
		
		$new_url = mr_image_resize($image[0], $width, $height, true);
		$post_img ='<a href="'.$link_to.'" class="'.$link_class.'" '.$rel.'><img src="'.$new_url.'" alt=""></a>';
		// removed code for image resize since 2.9.1		
		//$post_img = mysite_display_image( $img_args );
	}
	
	if( empty( $post_img ) && empty( $video ) )
		return;
		
	$offset = $mysite->layout['images']['image_padding'];
	$load_width = $width + $offset;
	$load_height = $height + $offset;
	
	$out = '<div class="' . $img_class . '"' . ( !empty( $inline_width ) ? 'style="width:' . $load_width . 'px;"' : '' ) . '>';
	
	if( empty( $placeholder ) ) {
		ob_start(); mysite_post_image_begin();
		$out .= ob_get_clean();
	}
	
	if( empty( $video ) )
		$out .= $post_img;
	else
		$out .= $video;
	
	if( empty( $placeholder ) ) {
		ob_start(); mysite_post_image_end( $args );
		$out .= ob_get_clean();
	}
	
	$out .= '</div>';
	
	if ( !empty( $echo ) )
		echo $out;
	else
		return $out;
}

/**
 *
 */
function mysite_image_by_attachment() {
	$attachments = get_children(array(
		'post_parent' => get_the_ID(),
		'post_status' => 'inherit',
		'post_type' => 'attachment',
		'post_mime_type' => 'image',
		'order' => 'ASC',
		'orderby' => 'menu_order ID',
		'numberposts' => 1
	));
	
	if ( empty( $attachments ) )
		return false;
		
	foreach ( $attachments as $id => $attachment ) {
		$image = wp_get_attachment_image_src( $id, '' );
		$image_tags = mysite_post_image_tags( $id );
		$alt = $image_tags['alt'];
	}
	
	return array( 'url' => $image[0], 'alt' => $alt );
}

/**
 *
 */
function mysite_post_image_tags( $image_id, $post_id = '' ) {
	
	# Check to is if attachment image has alt
	$alt = '';
	$file_name = '';
	if( is_numeric( $image_id ) ) {
		$alt = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
		$alt = esc_attr(trim( $alt ));
	}
	
	# If no alt generate from file name
	if( empty( $alt ) ) {
		$file = get_attached_file( $image_id );
		$info = pathinfo( $file );
		if( isset( $info['extension'] ) )
			$file_name =  basename( $file, '.' . $info['extension'] );
		
		if( !empty( $file_name ) )
			$alt = esc_attr(ucwords(str_replace( '-', ' ', str_replace( '_', ' ', $file_name ) )));
	}
	
	# Generate title tag from post title
	$title = '';
	
	if( !empty( $post_id ) )
		$title = esc_attr( apply_filters( 'the_title', get_post_field( 'post_title', $post_id ) ) );
		
	return array( 'title' => $title, 'alt' => $alt );
}

/**
 *
 */
function mysite_display_image( $args = array() ) {}

/**
 *
 */
function mysite_wp_image( $image, $width = '', $height = '' ) {}

/**
 *
 */
function mysite_wp_image_resize() {}

/**
 *
 */
function mysite_wpmu_image( $src ) {
	if( is_multisite() ) {
		
		global $blog_id;
		
		if ( defined( 'UPLOADS' ) ) {
			
			if( is_main_site( $blog_id ) ) {
				return $src;
				
			} else {
				
				$upload_dir = wp_upload_dir();
			 
				if( defined( 'DOMAIN_MAPPING' ) && function_exists('get_original_url') ) {
				
					$src = str_replace( trailingslashit( $upload_dir['baseurl'] ), trailingslashit( network_home_url() ) . trailingslashit( UPLOADS ) , $src );
					$src = str_replace( trailingslashit( get_original_url('siteurl') ), trailingslashit( network_home_url() ) . trailingslashit( UPLOADS ) , $src );
				
					return str_replace( '/files/files/', '/files/', $src );
				
				} else {
				
					return str_replace( trailingslashit( $upload_dir['baseurl'] ), trailingslashit( network_home_url() ) . trailingslashit( UPLOADS ) , $src );
				}
			}
			
		} else {
			
			return str_replace( trailingslashit( home_url() ), trailingslashit( network_home_url() ), $src );
		}

	} else {
		
		return $src;
	}
}

?>