<?php
/*
-------------------------------------------------------------------------
Credits: Bit Repository
URL: http://www.bitrepository.com/web-programming/php/download-image.html
-------------------------------------------------------------------------
*/
class GetImage {

var $source;
var $save_to;
var $set_extension;
var $quality;

function download($method = 'curl') // default method: cURL
{
$info = @GetImageSize($this->source);
$mime = $info['mime'];

if(!$mime) return false;
//exit('Could not obtain mime-type information. Make sure that the remote file is actually a valid image.');

// What sort of image?
$type = substr(strrchr($mime, '/'), 1);

switch ($type) 
{
case 'jpeg':
    $image_create_func = 'ImageCreateFromJPEG';
    $image_save_func = 'ImageJPEG';
	$new_image_ext = 'jpg';
	
	// Best Quality: 100
	$quality = isSet($this->quality) ? $this->quality : 100; 
    break;

case 'png':
    $image_create_func = 'ImageCreateFromPNG';
    $image_save_func = 'ImagePNG';
	$new_image_ext = 'png';
	
	// Compression Level: from 0  (no compression) to 9
	$quality = isSet($this->quality) ? $this->quality : 0;
    break;

case 'bmp':
    $image_create_func = 'ImageCreateFromBMP';
    $image_save_func = 'ImageBMP';
	$new_image_ext = 'bmp';
    break;

case 'gif':
    $image_create_func = 'ImageCreateFromGIF';
    $image_save_func = 'ImageGIF';
	$new_image_ext = 'gif';
    break;

case 'vnd.wap.wbmp':
    $image_create_func = 'ImageCreateFromWBMP';
    $image_save_func = 'ImageWBMP';
	$new_image_ext = 'bmp';
    break;

case 'xbm':
    $image_create_func = 'ImageCreateFromXBM';
    $image_save_func = 'ImageXBM';
	$new_image_ext = 'xbm';
    break;

default: 
	$image_create_func = 'ImageCreateFromJPEG';
    $image_save_func = 'ImageJPEG';
	$new_image_ext = 'jpg';
}

if(isSet($this->set_extension))
{
$ext = strrchr($this->source, ".");
$strlen = strlen($ext);
$new_name = basename(substr($this->source, 0, -$strlen)).'.'.$new_image_ext;
}
else
{
$new_name = basename($this->source);
}

$save_to = $this->save_to.$new_name;

    if($method == 'gd')
	{
	$img = @$image_create_func($this->source);

	    if(isSet($quality))
	    {
		   $save_image = $image_save_func($img, $save_to, $quality);
		}
		else
		{
		   $save_image = $image_save_func($img, $save_to);
		}
	}
	elseif($method == 'fread')
	{
		$save_image = $this->LoadImageFREAD($save_to);
	}
	
	return $save_image;
}

function LoadImageFREAD($save_to)
{
	WP_Filesystem();
    global $wp_filesystem;
$in = request_filesystem_credentials($this->source);
$out = request_filesystem_credentials($save_to);
while ( ( $chunk = get_file_data( $in, 8192 ) ) != '' ) {
    $wp_filesystem->get_contents( $out, $chunk, 8192 );
}

if( $chunk !== false )
	return true;
else
	return false;
}

}
?>