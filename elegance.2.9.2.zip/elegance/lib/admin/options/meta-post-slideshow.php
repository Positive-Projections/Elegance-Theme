<?php

$meta_boxes = array(
	'title' => sprintf( __( '%1$s Slideshow Post Options', 'elegance' ), THEME_NAME ),
	'id' => 'mysite_post_slideshow_meta_box',
	'pages' => array( 'post' ),
	'callback' => '',
	'context' => 'normal',
	'priority' => 'high',
	'fields' => array(
		array(
			'name' => __( 'Homepage Slider Image', 'elegance' ),
			'desc' => __( "Upload the image you'd like to use for the slideshow.", 'elegance' ),
			'id' => '_homepage_image',
			'toggle_class' => '_homepage_slider_image',
			'type' => 'upload'
		),
		array(
			'name' => __( 'Stage Effect', 'elegance' ),
			'desc' => __( "Select the the staging effect that you'd like for this slide.", 'elegance' ),
			'id' => '_homepage_slider_stage',
			'target' => 'slider_stage',
			'type' => 'select'
		),
		array(
			'name' => __( 'Disable Slider Text', 'elegance' ),
			'desc' => __( "Check this box if you'd like to disable the post excerpt content from appearing on the slideshow.", 'elegance' ),
			'id' => '_homepage_disable_excerpt',
			'options' => array( 'true' => __( 'Check to disable slider text', 'elegance' ) ),
			'type' => 'checkbox'
		)
	)
);
return array(
	'load' => true,
	'options' => $meta_boxes
);

?>