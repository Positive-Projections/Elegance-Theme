<?php
/**
 * Index Template
 *
 * "Simplicity is the ultimate sophistication." ~ Leonardo da Vinci
 *
 * @package Mysitemyway
 * @subpackage Template
 */

?>