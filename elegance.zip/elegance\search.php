<?php
/**
 * Search Template
 *
 * @package Mysitemyway
 * @subpackage Template
 */

get_header(); ?>

	<?php mysite_search(); ?>
	
	<?php mysite_after_page_content(); ?>

		<div class="clearboth"></div>
	</div><!-- #main_inner -->
</div><!-- #main -->

<?php get_footer(); ?>