<?php

$meta_boxes = array(
	'title' => sprintf( __( 'Testimonial Details', 'elegance' ), THEME_NAME ),
	'id' => 'mysite_testimonial_meta_box',
	'pages' => array( 'testimonial' ),
	'callback' => '',
	'context' => 'normal',
	'priority' => 'high',
	'fields' => array(
		array(
			'name' => __( 'Image', 'elegance' ),
			'desc' => __( 'Select the type of image you\'d liked displayed with your testimonial.', 'elegance' ),
			'id' => '_image',
			'options' => array( 
				'use_gravatar' => __( 'Use Gravatar', 'elegance' ),
				'upload_picture' => __( 'Upload Picture', 'elegance' ),
				'no_image' => __( 'No Image', 'elegance' )
			),
			'toggle' => 'toggle_true',
			'type' => 'radio'
		),
		array(
			'name' => __( 'Custom Image', 'elegance' ),
			'desc' => __( 'Upload an image to use for this testimonial.', 'elegance' ),
			'id' => '_custom_image',
			'toggle_class' => '_image_upload_picture',
			'type' => 'upload'
		),
		array(
			'name' => __( 'Email <small>(for Gravatar support)</small>', 'elegance' ),
			'desc' => __( 'Enter the email address for the Gravatar you\'d like displayed, if no Gravatar is found your themes default will be used.', 'elegance' ),
			'id' => '_email',
			'toggle_class' => '_image_use_gravatar',
			'type' => 'text'
		),
		array(
			'name' => __( 'Name', 'elegance' ),
			'desc' => __( 'Enter the name for this testimonial.', 'elegance' ),
			'id' => '_name',
			'type' => 'text'
		),
		array(
			'name' => __( 'Website Name', 'elegance' ),
			'desc' => __( 'Enter the website name for this testimonial.', 'elegance' ),
			'id' => '_website_name',
			'type' => 'text'
		),
		array(
			'name' => __( 'Website URL', 'elegance' ),
			'desc' => __( 'Enter the website url for this testimonial.', 'elegance' ),
			'id' => '_website_url',
			'type' => 'text'
		),
		array(
			'name' => __( 'Testimonial', 'elegance' ),
			'desc' => __( 'Enter your testimonial.', 'elegance' ),
			'id' => '_testimonial',
			'no_header' => true,
			'type' => 'editor'
		),
	)
);
return array(
	'load' => true,
	'options' => $meta_boxes
);

?>