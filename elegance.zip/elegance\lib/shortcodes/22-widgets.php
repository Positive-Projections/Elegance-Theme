<?php
/**
 *
 */
  /*--------since 2.9.1------------*/
class mysiteWidgets {
	
	/**
	 *
	 */
	static function testimonial( $atts = null ) {
		
		if( $atts == 'generator' ) {
			$numbers = range(1,20);
			foreach( $numbers as $val )
				$number[$val] = $val;
				
			$option = array( 
				'name' => __( 'Testimonial', 'elegance' ),
				'value' => 'testimonial',
				'options' => array(
					array(
						'name' => __( 'Count', 'elegance' ),
						'desc' => __( 'Select how many testimonials you want to be displayed.', 'elegance' ),
						'id' => 'number',
						'default' => '',
						'options' => $number,
						'type' => 'select'
					),
					array(
						'name' => __('Testimonials Categories <small>(optional)</small>', 'elegance' ),
						'desc' => __( 'If you want testimonials from specific categories to display then you may choose them here.', 'elegance' ),
						'id' => 'cat',
						'default' => array(),
						'target' => 'cat_testimonial',
						'type' => 'multidropdown'
					),
				'shortcode_has_atts' => true,
				)
			);

			return $option;
		}
		
		$defaults = array(
			'title' 			=> ' ',
			'number'			=> '4',
			'cat'				=> '',
			'testimonial_sc'	=> 'true',
		);
		
		$atts = wp_parse_args( $atts, $defaults );
		
		$instance = http_build_query( $atts );

		$args = array( 'widget_name' => 'MySite_Testimonial_Widget', 'instance' => $instance );
		
		$widget = new mysiteWidgets();
		return $widget->_widget_generator( $args );
	}

	/**
	 *
	 */
	static function twitter( $atts = null ) {
		if( $atts == 'generator' ) {
			$numbers = range(1,20);
			foreach( $numbers as $val )
				$number[$val] = $val;

			$option = array( 
				'name' => __( 'Twitter', 'elegance' ),
				'value' => 'twitter',
				'options' => array(
					array(
						'name' => __( 'Username', 'elegance' ),
						'desc' => __( 'Paste your twitter username here.  You can find your username by going to your settings page within twitter.', 'elegance' ),
						'id' => 'id',
						'default' => '',
						'type' => 'text'
					),
					array(
						'name' => __( 'Count', 'elegance' ),
						'desc' => __( 'Select how many tweets you want to be displayed.', 'elegance' ),
						'id' => 'number',
						'default' => '',
						'options' => $number,
						'type' => 'select'
					),
				'shortcode_has_atts' => true,
				)
			);

			return $option;
		}
		
		$defaults = array(
			'id' 		=> '',
			'number'	=> '1',
			'title' 	=> ' '
		);
		
		if( isset( $atts['count'] ) )
			$atts['number'] = $atts['count'];
		
		if( isset( $atts['username'] ) )
			$atts['id'] = $atts['username'];
			
		if( empty( $atts['id'] ) )
			$atts['id'] = mysite_get_setting( 'twitter_id' );
			
		$atts = wp_parse_args( $atts, $defaults );
		
		$instance = http_build_query( $atts );

		$args = array( 'widget_name' => 'MySite_Twitter_Widget', 'instance' => $instance );
		
		$widget = new mysiteWidgets();
		return $widget->_widget_generator( $args );
	}
	
	/**
	 *
	 */
	static function flickr( $atts = null ) {
		if( $atts == 'generator' ) {
			$numbers = range(1,20);
			foreach( $numbers as $val )
				$number[$val] = $val;

			$option = array( 
				'name' => __( 'Flickr', 'elegance' ),
				'value' => 'flickr',
				'options' => array(
					array(
						'name' => __( 'Flickr id (<a target="_blank" href="http://idgettr.com/">idGettr</a>)', 'elegance' ),
						'desc' => __( 'Set your Flickr ID here.  You can use the idGettr service to easily find your ID.', 'elegance' ),
						'id' => 'id',
						'default' => '',
						'type' => 'text'
					),
					array(
						'name' => __( 'Count', 'elegance' ),
						'desc' => __( 'Select how many flickr images you wish to display.', 'elegance' ),
						'id' => 'count',
						'default' => '',
						'options' => $number,
						'type' => 'select'
					),
					array(
						'name' => __( 'Size', 'elegance' ),
						'desc' => __( 'Set the size of your flickr images.<br /><br />Each setting will display differently so try and experiment with them to find which one suits you best.', 'elegance' ),
						'id' => 'size',
						'default' => '',
						'options' => array(
							's' => __('Square', 'elegance' ),
							't' => __('Thumbnail', 'elegance' ),
							'm' => __('Medium', 'elegance' )
						),
						'type' => 'select'
					),
					array(
						'name' => __('Display', 'elegance' ),
						'desc' => __( 'Select whether you want your latest images to display or a random selection.', 'elegance' ),
						'id' => 'display',
						'default' => '',
						'options' => array(
							'latest' => __('Latest', 'elegance' ),
							'random' => __('Random', 'elegance' )
						),
						'type' => 'select'
					),
				'shortcode_has_atts' => true,
				)
			);

			return $option;
		}
		
		$defaults = array(
			'id' 		=> '44071822@N08',
			'number'	=> '9',
			'display'	=> 'latest',
			'size'		=> 's',
			'title' 	=> ' '
		);
		
		$atts = wp_parse_args( $atts, $defaults );
		
		$instance = http_build_query( $atts );

		$args = array( 'widget_name' => 'MySite_Flickr_Widget', 'instance' => $instance );
		
		$widget = new mysiteWidgets();
		return $widget->_widget_generator( $args );
	}
	
	/**
	 *
	 */
	static function recent_posts( $atts = null ) {
		if( $atts == 'generator' ) {
			$numbers = range(1,20);
			foreach( $numbers as $val )
				$number[$val] = $val;

			$option = array( 
				'name' => __( 'Recent Posts', 'elegance' ),
				'value' => 'recent_posts',
				'options' => array(
					array(
						'name' => __( 'Number', 'elegance' ),
						'desc' => __( 'Select the number of posts you wish to display.', 'elegance' ),
						'id' => 'number',
						'default' => '',
						'options' => $number,
						'type' => 'select'
					),
					array(
						'name' => __( 'Thumbnail', 'elegance' ),
						'desc' => __( 'Choose whether you want thumbnails to display alongside your posts.  The thumbnail uses the featured image of your post.', 'elegance' ),
						'id' => 'disable_thumb',
						'default' => '',
						'options' => array(
							'0' => __( 'Yes', 'elegance' ),
							'1' => __( 'No', 'elegance' )
						),
						'type' => 'select'
					),
				'shortcode_has_atts' => true,
				)
			);

		return $option;
		
		}
		
		$defaults = array(
			'number'	=> '',
			'disable_thumb'	=> '',
			'title' 	=> ' '
		);
		
		$atts = wp_parse_args( $atts, $defaults );
		
		$instance = http_build_query( $atts );

		$args = array( 'widget_name' => 'MySite_RecentPost_Widget', 'instance' => $instance );
		
		$widget = new mysiteWidgets();
		return $widget->_widget_generator( $args );
	}
	
	/**
	 *
	 */
	static function popular_posts( $atts = null ) {
		if( $atts == 'generator' ) {
			$numbers = range(1,20);
			foreach( $numbers as $val )
				$number[$val] = $val;

			$option = array( 
				'name' => __( 'Popular Posts', 'elegance' ),
				'value' => 'popular_posts',
				'options' => array(
					array(
						'name' => __( 'Number', 'elegance' ),
						'desc' => __( 'Select the number of posts you wish to display.', 'elegance' ),
						'id' => 'number',
						'default' => '',
						'options' => $number,
						'type' => 'select'
					),
					array(
						'name' => __( 'Thumbnail', 'elegance' ),
						'desc' => __( 'Choose whether you want thumbnails to display alongside your posts.  The thumbnail uses the featured image of your post.', 'elegance' ),
						'id' => 'disable_thumb',
						'default' => '',
						'options' => array(
							'0' => __( 'Yes', 'elegance' ),
							'1' => __( 'No', 'elegance' )
						),
						'type' => 'select'
					),
				'shortcode_has_atts' => true,
				)
			);

		return $option;
		
		}
		
		$defaults = array(
			'number'	=> '',
			'disable_thumb'	=> '',
			'title' 	=> ' '
		);
		
		$atts = wp_parse_args( $atts, $defaults );
		
		$instance = http_build_query( $atts );

		$args = array( 'widget_name' => 'MySite_PopularPost_Widget', 'instance' => $instance );
		
		$widget = new mysiteWidgets();
		return $widget->_widget_generator( $args );
	}
	
	/**
	 *
	 */
	static function contact_info( $atts = null ) {
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Contact Info', 'elegance' ),
				'value' => 'contact_info',
				'options' => array(
					array(
						'name' => __( 'Name', 'elegance' ),
						'desc' => __( 'Type in your name.', 'elegance' ),
						'id' => 'name',
						'default' => '',
						'type' => 'text'
					),
					array(
						'name' => __( 'Phone', 'elegance' ),
						'desc' => __( 'Type in your phone number.', 'elegance' ),
						'id' => 'phone',
						'default' => '',
						'type' => 'text'
					),
					array(
						'name' => __( 'Email', 'elegance' ),
						'desc' => __( 'Type in your email address.', 'elegance' ),
						'id' => 'email',
						'default' => '',
						'type' => 'text'
					),
					array(
						'name' => __( 'Address', 'elegance' ),
						'desc' => __( 'Type in your address.', 'elegance' ),
						'id' => 'address',
						'default' => '',
						'type' => 'text'
					),
					array(
						'name' => __( 'City', 'elegance' ),
						'desc' => __( 'Type in your city.', 'elegance' ),
						'id' => 'city',
						'default' => '',
						'type' => 'text'
					),
					array(
						'name' => __( 'State', 'elegance' ),
						'desc' => __( 'Type in your state.', 'elegance' ),
						'id' => 'state',
						'default' => '',
						'type' => 'text'
					),
					array(
						'name' => __( 'Zip', 'elegance' ),
						'desc' => __( 'Type in your zip.', 'elegance' ),
						'id' => 'zip',
						'default' => '',
						'type' => 'text'
					),
				'shortcode_has_atts' => true,
				)
			);

			return $option;
		}
		
		$defaults = array(
			'name'          => '',
			'address' 	=> '',
			'city'          => '',
			'state'         => '',
			'zip'           => '',
			'phone'         => '',
			'email'         => '',
			'title'         => ' '
		);
		
		$atts = wp_parse_args( $atts, $defaults );
		
		$instance = http_build_query( $atts );

		$args = array( 'widget_name' => 'MySite_Contact_Widget', 'instance' => $instance );
		
		$widget = new mysiteWidgets();
		return $widget->_widget_generator( $args );
	}
	
	/**
	 *
	 */
	static function comments( $atts = null ) {
		if( $atts == 'generator' ) {
			$numbers = range(1,20);
			foreach( $numbers as $val )
				$number[$val] = $val;

			$option = array( 
				'name' => __( 'Comments', 'elegance' ),
				'value' => 'comments',
				'options' => array(
					array(
						'name' => __( 'Number', 'elegance' ),
						'desc' => __( 'Select the number of comments you wish to display.', 'elegance' ),
						'id' => 'number',
						'default' => '',
						'options' => $number,
						'type' => 'select'
					),
				'shortcode_has_atts' => true,
				)
			);

			return $option;
		}
			
		$defaults = array(
			'title' => ' ',
			'number' => '5'
		);
		
		$atts = wp_parse_args( $atts, $defaults );
		
		$instance = http_build_query( $atts );

		$args = array( 'widget_name' => 'WP_Widget_Recent_Comments', 'instance' => $instance );
		
		$widget = new mysiteWidgets();
		return $widget->_widget_generator( $args );
	}
	
	/**
	 *
	 */
	static function tags( $atts = null ) {
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Tags', 'elegance' ),
				'value' => 'tags',
				'options' => array(
					array(
						'name' => __( 'Taxonomy', 'elegance' ),
						'desc' => __( 'Select whether you wish to display categories or tags.', 'elegance' ),
						'id' => 'taxonomy',
						'default' => '',
						'options' => array(
							'post_tag' => __( 'Post Tags', 'elegance' ),
							'category' => __( 'Category', 'elegance' )
						),
						'type' => 'select'
					),
				'shortcode_has_atts' => true,
				)
			);

			return $option;
		}
		
		$defaults = array(
			'title' => ' ',
			'taxonomy' => 'post_tag'
		);
			
		$atts = wp_parse_args( $atts, $defaults );
		
		$instance = http_build_query( $atts );

		$args = array( 'widget_name' => 'WP_Widget_Tag_Cloud', 'instance' => $instance );
		
		$widget = new mysiteWidgets();
		return $widget->_widget_generator( $args );
	}

	/**
	 *
	 */
	static function rss( $atts = null ) {
		if( $atts == 'generator' ) {
			$numbers = range(1,20);
			foreach( $numbers as $val ) {
				$number[$val] = $val;
			}

			$option = array( 
				'name' => __( 'Rss', 'elegance' ),
				'value' => 'rss',
				'options' => array(
					array(
						'name' => __( 'RSS feed URL', 'elegance' ),
						'desc' => __( 'Paste the URL to your feed.  For example if you are using feedburner then you would paste something like this,<br /><br />http://feeds.feedburner.com/username', 'elegance' ),
						'id' => 'url',
						'default' => '',
						'type' => 'text'
					),
					array(
						'name' => __( 'How many items would you like to display?', 'elegance' ),
						'desc' => __( 'Select the number of RSS items you wish to display.', 'elegance' ),
						'id' => 'items',
						'default' => '',
						'options' => $number,
						'type' => 'select'
					),
					array(
						'name' => __( 'Show Summary', 'elegance' ),
						'desc' => __( 'Check this if you wish to display a summary of the item.', 'elegance' ),
						'id' => 'show_summary',
						'options' => array( '1' => __( 'Show Summary', 'elegance' )),
						'default' => '',
						'type' => 'checkbox'
					),
					array(
						'name' => __( 'Show Author', 'elegance' ),
						'desc' => __( 'Check if you wish to display the author of the item.', 'elegance' ),
						'id' => 'show_author',
						'options' => array( '1' => __( 'Show Author', 'elegance' )),
						'default' => '',
						'type' => 'checkbox'
					),
					array(
						'name' => __( 'Show Date', 'elegance' ),
						'desc' => __( 'Check if you wish to display the date of the item.', 'elegance' ),
						'id' => 'show_date',
						'options' => array( '1' => __( 'Show Date', 'elegance' )),
						'default' => '',
						'type' => 'checkbox'
					),
				'shortcode_has_atts' => true,
				)
			);
			
			return $option;
		}
		
		$defaults = array(
			'title' => ' ',
			'url' => '',
			'items' => 3,
			'error' => false,
			'show_summary' => 0,
			'show_author' => 0,
			'show_date' => 0
		);
		
		$atts = wp_parse_args( $atts, $defaults );
		
		$instance = http_build_query( $atts );

		$args = array( 'widget_name' => 'WP_Widget_RSS', 'instance' => $instance );
		
		$widget = new mysiteWidgets();
		return $widget->_widget_generator( $args );
	}
	
	/**
	 *
	 */
	static function search( $atts = null ) {
		
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Search', 'elegance' ),
				'value' => 'search'
			);

			return $option;
		}
		
		$defaults = array( 'title' => ' ' );
		
		$atts = wp_parse_args( $atts, $defaults );
		
		$instance = http_build_query( $atts );

		$args = array( 'widget_name' => 'WP_Widget_Search', 'instance' => $instance );
		
		$widget = new mysiteWidgets();
		return $widget->_widget_generator( $args );
	}

	/**
	 *
	 */
	static function _widget_generator( $args = array() ) {
		global $wp_widget_factory;
		
		$widget_name = esc_html( $args['widget_name'] );

		ob_start();
		the_widget( $widget_name, $args['instance'], array( 'before_title' => '', 'after_title' => '', 'widget_id' => '-1' ) );
		$out = ob_get_contents();
		ob_end_clean();
		return $out;
	}

	/**
	 *
	 */
	static function _options( $class ) {
		$shortcode = array();
		
		$class_methods = get_class_methods( $class );
		
		foreach( $class_methods as $method ) {
			if( $method[0] != '_' ) {
				$shortcode[] = call_user_func(array( &$class, $method ), $atts = 'generator' );
			}
		}
		
		$options = array(
			'name' => __( 'Widget', 'elegance' ),
			'desc' => __( 'Select which widget shortcode you would like to use.', 'elegance' ),
			'value' => 'widget',
			'options' => $shortcode,
			'shortcode_has_types' => true
		);
		
		return $options;
	}
	
}

?>